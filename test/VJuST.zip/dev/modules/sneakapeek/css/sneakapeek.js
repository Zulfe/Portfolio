#backdrop {
    height: 100%;
    width: auto;
}
